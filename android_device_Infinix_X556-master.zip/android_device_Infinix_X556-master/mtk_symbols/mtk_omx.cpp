extern "C" {
    void _ZN7android13AwesomePlayer24mtk_omx_get_current_timeEPx(long long* time){
        time = (long long*)-1;
    }
}