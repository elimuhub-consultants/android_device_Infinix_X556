extern "C" {
    /* MediaBufferGroup::MediaBufferGroup */
    int _ZN7android16MediaBufferGroupC1Ej(unsigned int);
    int _ZN7android16MediaBufferGroupC1Ev() {
        return _ZN7android16MediaBufferGroupC1Ej(0);
    }
}
