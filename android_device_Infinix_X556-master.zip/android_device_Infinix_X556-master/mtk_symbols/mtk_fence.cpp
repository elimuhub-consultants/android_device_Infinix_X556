extern "C" {
    void _ZN7android5Fence4waitEi(int);
}
