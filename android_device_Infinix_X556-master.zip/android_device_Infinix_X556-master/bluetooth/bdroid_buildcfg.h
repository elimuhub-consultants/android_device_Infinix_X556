#ifndef _BDROID_BUILDCFG_H
#define _BDROID_BUILDCFG_H

#define BTM_DEF_LOCAL_NAME   "Infinix HOT 4 Pro"
// test
//#define KERNEL_MISSING_CLOCK_BOOTTIME_ALARM TRUE
#define BTA_DISABLE_DELAY 1000 /* in milliseconds */
#define BLE_VND_INCLUDED   TRUE
#endif